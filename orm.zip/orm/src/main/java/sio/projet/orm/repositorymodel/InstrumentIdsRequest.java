package sio.projet.orm.repositorymodel;

import java.time.LocalDate;
import java.util.List;

public class InstrumentIdsRequest {
    private List<Long> instrumentIds;

    public List<Long> getInstrumentIds() {
        return instrumentIds;
    }

    public void setInstrumentIds(List<Long> instrumentIds) {
        this.instrumentIds = instrumentIds;
    }
}


