package sio.projet.orm;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sio.projet.orm.api.BandNotFoundException;
import sio.projet.orm.api.model.BandCreationRequest;
import sio.projet.orm.api.model.FestivalCreationRequest;
import sio.projet.orm.repositorymodel.Band;
import sio.projet.orm.repositorymodel.Festival;
import sio.projet.orm.service.BandService;
import sio.projet.orm.service.FestivalService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/bands")
public class BandController {
    private final BandService bandService;
    private final FestivalService festivalService;

    public BandController(BandService bandService, FestivalService festivalService) {
        this.bandService = bandService;
        this.festivalService = festivalService;
    }

    @PostMapping
    public Band createBand(@RequestBody BandCreationRequest bandCreationRequest) {
        return bandService.createBand(bandCreationRequest);
    }

    @GetMapping("/{id}")
    public Band getBand(@PathVariable long id) throws BandNotFoundException {
        return bandService.getBand(id).orElseThrow(() -> new BandNotFoundException());
    }

    @PostMapping("/{bandId}/musicians")
    public Band addMusiciansToBand(@PathVariable long bandId, @RequestBody List<Long> musicianIds) throws BandNotFoundException {
        return bandService.addMusiciansToBand(bandId, musicianIds);
    }

    @PostMapping("/bands/{bandId}/festivals/{festivalId}")
    public ResponseEntity<Band> addFestivalToBank(@PathVariable Long bandId, @PathVariable Long festivalId) {
        Band band = bandService.addFestivalToBand(bandId, festivalId);
        return ResponseEntity.ok(band);
    }
}
