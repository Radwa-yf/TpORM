package sio.projet.orm.api.model;

import sio.projet.orm.repositorymodel.Instrument;

import java.time.LocalDate;
import java.util.List;

public record CreateMusicianRequest(String firstName, String lastName, String email, int age, LocalDate joinDate, LocalDate leaveDate, Iterable <Long> instrumentIds) {

}