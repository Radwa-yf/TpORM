package sio.projet.orm.service;

import sio.projet.orm.api.BandNotFoundException;
import sio.projet.orm.api.ResourceNotFoundException;
import sio.projet.orm.api.model.BandCreationRequest;
import sio.projet.orm.api.model.FestivalCreationRequest;
import sio.projet.orm.repositorymodel.*;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;


@Service
public class BandService {
    private final BandRepository bandRepository;
    private final MusicianRepository musicianRepository;
    private final FestivalRepository festivalRepository;

    public BandService(BandRepository bandRepository, MusicianRepository musicianRepository, FestivalRepository festivalRepository) {
        this.bandRepository = bandRepository;
        this.musicianRepository = musicianRepository;
        this.festivalRepository = festivalRepository;
    }

    public Band createBand(BandCreationRequest bandCreationRequest) {
        Band band = new Band();
        band.setBandName(bandCreationRequest.bandName());
        return bandRepository.save(band);
    }

    public Optional<Band> getBand(long id) {
        return bandRepository.findById(id);
    }

    public Band addMusiciansToBand(long bandId, List<Long> musicianIds) throws BandNotFoundException {
        Band band = bandRepository.findById(bandId).orElseThrow(() -> new BandNotFoundException());
        List<Musician> musicians = musicianRepository.findAllById(musicianIds);
        band.getMusicians().addAll(musicians);
        return bandRepository.save(band);
    }

    public Band addFestivalsToBand(long bandId, List<Long> festivalIds) throws BandNotFoundException {
        Band band = bandRepository.findById(bandId).orElseThrow(() -> new BandNotFoundException());
        List<Festival> festivals = festivalRepository.findAllById(festivalIds);
        band.getFestivals().addAll(festivals);
        return bandRepository.save(band);
    }

    public Band addFestivalToBand(Long bandId, Long festivalId) {
        Band band = bandRepository.findById(bandId)
                .orElseThrow();

        Festival festival = festivalRepository.findById(festivalId)
                .orElseThrow();

        band.addFestival(festival);
        return bandRepository.save(band);
    }

}
