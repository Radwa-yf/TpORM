package sio.projet.orm.config;

public class DBConfig {
}
