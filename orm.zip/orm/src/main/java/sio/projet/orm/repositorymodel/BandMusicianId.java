package sio.projet.orm.repositorymodel;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EmbeddedId;

import java.io.Serializable;

@Embeddable
public class BandMusicianId implements Serializable {

    @Column(name = "musician_id")
    private Long musicianId;

    @Column(name = "band_id")
    private Long bandId;

    public BandMusicianId(Long musicianId, Long bandId) {
        this.musicianId = musicianId;
        this.bandId = bandId;
    }

    public BandMusicianId() {

    }

    public Long getMusicianId() {
        return musicianId;
    }

    public void setMusicianId(Long musicianId) {
        this.musicianId = musicianId;
    }

    public Long getBandId() {
        return bandId;
    }

    public void setBandId(Long bandId) {
        this.bandId = bandId;
    }
}
