package sio.projet.orm.repositorymodel;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "MUSICIAN")
public class Musician {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "person_id")
    private Person person;

    @ManyToMany
    @JoinTable(
            name = "BAND_MUSICIAN",
            joinColumns = {
                    @JoinColumn(name = "musician_id", referencedColumnName = "id")
            },
            inverseJoinColumns = {
                    @JoinColumn(name = "band_id", referencedColumnName = "id")
            }
    )

    @JsonIgnore
    private List<Band> bands = new ArrayList<>();
    @JsonManagedReference

    @ManyToMany
    @JoinTable(
            name = "MUSICIAN_INSTRUMENT",
            joinColumns = {
                    @JoinColumn(name = "musician_id", referencedColumnName = "id")
            },
            inverseJoinColumns = {
                    @JoinColumn(name = "instrument_id", referencedColumnName = "id")
            }
    )
    private Set<Instrument> instruments = new HashSet<>();

    public Musician(Long id, Person person, List<Band> bands, Set<Instrument> instruments) {
        this.id = id;
        this.person = person;
        this.bands = bands;
        this.instruments = instruments;
    }

    public Musician() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public List<Band> getBands() {
        return bands;
    }

    public void setBands(List<Band> bands) {
        this.bands = bands;
    }

    public Set<Instrument> getInstruments() {
        return instruments;
    }

    public void setInstruments(Set<Instrument> instruments) {
        this.instruments = instruments;
    }
}

