package sio.projet.orm.api;

public class MusicianNotFoundException extends Throwable {
}
