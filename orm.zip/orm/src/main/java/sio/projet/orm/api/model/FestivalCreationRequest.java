package sio.projet.orm.api.model;

import java.time.LocalDate;

public class FestivalCreationRequest {
    private String name;
    private String city;
    private LocalDate date;
    private double price;
    private long bandId;  // Ajouter un champ pour l'ID du groupe

    // Constructeur
    public FestivalCreationRequest(String name, String city, LocalDate date, double price, long bandId) {
        this.name = name;
        this.city = city;
        this.date = date;
        this.price = price;
        this.bandId = bandId;
    }

    // Getters et setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public long getBandId() {
        return bandId;
    }

    public void setBandId(long bandId) {
        this.bandId = bandId;
    }
}
