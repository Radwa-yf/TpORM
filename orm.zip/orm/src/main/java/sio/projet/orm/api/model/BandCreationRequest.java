package sio.projet.orm.api.model;

import jakarta.validation.constraints.NotBlank;

public record BandCreationRequest(String bandName) {

}

