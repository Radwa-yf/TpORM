package sio.projet.orm.repositorymodel;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "BAND")
public class Band {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "band_name")
    private String bandName;

    @ManyToMany(mappedBy = "bands")
    private List<Musician> musicians = new ArrayList<>();


    @JsonBackReference
    @ManyToMany
    @JoinTable(
            name = "BAND_FESTIVAL",
            joinColumns = {
                    @JoinColumn(name = "band_id", referencedColumnName = "id")
            },
            inverseJoinColumns = {
                    @JoinColumn(name = "festival_id", referencedColumnName = "id")
            }
    )
    private List<Festival> festivals = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBandName() {
        return bandName;
    }

    public void setBandName(String bandName) {
        this.bandName = bandName;
    }

    public List<Musician> getMusicians() {
        return musicians;
    }

    public void setMusicians(List<Musician> musicians) {
        this.musicians = musicians;
    }

    public List<Festival> getFestivals() {
        return festivals;
    }

    public void setFestivals(List<Festival> festivals) {
        this.festivals = festivals;
    }

    public void addFestival(Festival festival) {
        if (!this.festivals.contains(festival)) {
            this.festivals.add(festival);
        }
    }


}
