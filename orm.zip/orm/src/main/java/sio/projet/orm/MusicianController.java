package sio.projet.orm;

import org.springframework.web.bind.annotation.*;
import sio.projet.orm.api.BandNotFoundException;
import sio.projet.orm.api.MusicianNotFoundException;
import sio.projet.orm.api.model.CreateMusicianRequest;
import sio.projet.orm.repositorymodel.*;
import sio.projet.orm.service.MusicianService;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/v1/musicians")
public class MusicianController {
    private final MusicianService musicianService;
    private final BandMusicianRepository bandMusicianRepository;

    public MusicianController(MusicianService musicianService, BandMusicianRepository bandMusicianRepository) {
        this.musicianService = musicianService;
        this.bandMusicianRepository = bandMusicianRepository;
    }

    @PostMapping
    public Musician createMusician(@RequestBody CreateMusicianRequest createMusicianRequest) {
        return musicianService.createMusician(createMusicianRequest);
    }

    @GetMapping("/{id}")
    public Musician getMusician(@PathVariable long id) throws MusicianNotFoundException {
        return musicianService.getMusician(id).orElseThrow(() -> new MusicianNotFoundException());
    }

    @GetMapping("/person/{personId}")
    public List<Musician> getMusiciansByPersonId(@PathVariable long personId) {
        return musicianService.getMusiciansByPersonId(personId);
    }

    @PostMapping("/{musicianId}/instruments")
    public Musician addInstrumentsToMusician(@PathVariable long musicianId, @RequestBody InstrumentIdsRequest instrumentIdsRequest) throws MusicianNotFoundException {
        return musicianService.addInstrumentsToMusician(musicianId, instrumentIdsRequest.getInstrumentIds());
    }

    @PostMapping("/{musicianId}/bands/{bandId}")
    public Musician addMusicianToBand(@PathVariable long musicianId, @PathVariable long bandId, @RequestBody MusicianBandRequest musicianBandRequest) throws MusicianNotFoundException, BandNotFoundException {
        return musicianService.addMusicianToBand(musicianId, bandId, musicianBandRequest.getJoinDate(), musicianBandRequest.getLeaveDate());
    }


    @GetMapping("/{musicianId}/bands")
    public List<BandWithJoinLeaveDatesDTO> getBandsByMusicianId(@PathVariable long musicianId) {
        List<Band> bands = musicianService.getBandsByMusicianId(musicianId);
        List<BandWithJoinLeaveDatesDTO> bandDTOs = new ArrayList<>();

        for (Band band : bands) {
            BandMusician bandMusician = bandMusicianRepository.findByMusicianIdAndBandId(musicianId, band.getId());
            BandWithJoinLeaveDatesDTO bandDTO = BandWithJoinLeaveDatesDTO.fromEntity(band, bandMusician);
            bandDTOs.add(bandDTO);
        }

        return bandDTOs;
    }



}

