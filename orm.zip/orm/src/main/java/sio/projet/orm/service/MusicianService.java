package sio.projet.orm.service;

import org.springframework.stereotype.Service;
import sio.projet.orm.api.BandNotFoundException;
import sio.projet.orm.api.MusicianNotFoundException;
import sio.projet.orm.api.model.CreateMusicianRequest;
import sio.projet.orm.repositorymodel.*;

import java.time.LocalDate;
import java.util.*;

@Service
public class MusicianService {
    private final MusicianRepository musicianRepository;
    private final PersonRepository personRepository;
    private final InstrumentRepository instrumentRepository;
    private final BandMusicianRepository bandMusicianRepository;
    private final BandRepository bandRepository;

    public MusicianService(MusicianRepository musicianRepository, PersonRepository personRepository, InstrumentRepository instrumentRepository, BandMusicianRepository bandMusicianRepository, BandRepository bandRepository) {
        this.musicianRepository = musicianRepository;
        this.personRepository = personRepository;
        this.instrumentRepository = instrumentRepository;
        this.bandMusicianRepository = bandMusicianRepository;
        this.bandRepository = bandRepository;
    }

    public Musician createMusician(CreateMusicianRequest createMusicianRequest) {
        Musician musician = new Musician();
        Person person = new Person();
        person.setFirstName(createMusicianRequest.firstName());
        person.setLastName(createMusicianRequest.lastName());
        person.setEmail(createMusicianRequest.email());
        person.setAge(createMusicianRequest.age());
        personRepository.save(person);

        musician.setPerson(person);
        musician.setInstruments((Set<Instrument>) instrumentRepository.findAllById(createMusicianRequest.instrumentIds()));

        return musicianRepository.save(musician);
    }

    public Optional<Musician> getMusician(long id) {
        return musicianRepository.findById(id);
    }

    public List<Musician> getMusiciansByPersonId(long personId) {
        return musicianRepository.findByPersonId(personId);
    }

    public Musician addInstrumentsToMusician(long musicianId, List<Long> instrumentIds) throws MusicianNotFoundException {
        Musician musician = musicianRepository.findById(musicianId).orElseThrow(() -> new MusicianNotFoundException());
        List<Instrument> instruments = instrumentRepository.findAllById(instrumentIds);
        for (Instrument instrument : instruments) {
            if (!musician.getInstruments().contains(instrument)) {
                musician.getInstruments().add(instrument);
            }
        }

        return musicianRepository.save(musician);
    }

    public Musician addMusicianToBand(long musicianId, long bandId, LocalDate joinDate, LocalDate leaveDate) throws MusicianNotFoundException, BandNotFoundException {
        Musician musician = musicianRepository.findById(musicianId).orElseThrow(() -> new MusicianNotFoundException());
        Band band = bandRepository.findById(bandId).orElseThrow(() -> new BandNotFoundException());

        BandMusicianId id = new BandMusicianId(musicianId, bandId);
        BandMusician bandMusician = new BandMusician(id, musician, band, joinDate, leaveDate);
        bandMusicianRepository.save(bandMusician);

        return musician;
    }

    public List<Band> getBandsByMusicianId(long musicianId) {
        List<BandMusician> bandMusicians = bandMusicianRepository.findByMusicianId(musicianId);
        List<Band> bands = new ArrayList<>();
        for (BandMusician bandMusician : bandMusicians) {
            bands.add(bandMusician.getBand());
        }
        return bands;
    }
}

