package sio.projet.orm.repositorymodel;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
public interface BandMusicianRepository extends JpaRepository<BandMusician, BandMusicianId> {
    @Query("SELECT bm FROM BandMusician bm WHERE bm.id.musicianId = :musicianId AND bm.id.bandId = :bandId")
    BandMusician findByMusicianIdAndBandId(@Param("musicianId") long musicianId, @Param("bandId") long bandId);
    List<BandMusician> findByMusicianId(long musicianId);
    List<BandMusician> findByBandId(long bandId);
}

