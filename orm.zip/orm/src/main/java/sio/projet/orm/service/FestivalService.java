package sio.projet.orm.service;

import org.springframework.stereotype.Service;
import sio.projet.orm.api.model.FestivalCreationRequest;
import sio.projet.orm.repositorymodel.Band;
import sio.projet.orm.repositorymodel.BandRepository;
import sio.projet.orm.repositorymodel.Festival;
import sio.projet.orm.repositorymodel.FestivalRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class FestivalService {
    private final FestivalRepository festivalRepository;
    private final BandRepository bandRepository;

    public FestivalService(FestivalRepository festivalRepository,BandRepository bandRepository) {
        this.festivalRepository = festivalRepository;
        this.bandRepository = bandRepository;
    }

    public Festival createFestival(FestivalCreationRequest festivalCreationRequest) {
        Festival festival = new Festival();
        festival.setName(festivalCreationRequest.getName());
        festival.setCity(festivalCreationRequest.getCity());
        festival.setDate(festivalCreationRequest.getDate());
        festival.setPrice(festivalCreationRequest.getPrice());
        Optional<Band> band = bandRepository.findById(festivalCreationRequest.getBandId());
        band.ifPresent(b -> festival.addBand(b));
        return festivalRepository.save(festival);
    }

    public Optional<Festival> getFestival(long id) {
        return festivalRepository.findById(id);
    }
    public Festival addBandToFestival(long festivalId, long bandId) {
        Optional<Festival> festivalOptional = festivalRepository.findById(festivalId);
        Optional<Band> bandOptional = bandRepository.findById(bandId);

        if (festivalOptional.isPresent() && bandOptional.isPresent()) {
            Festival festival = festivalOptional.get();
            Band band = bandOptional.get();
            festival.addBand(band);  // Assurez-vous que cette méthode est définie dans Festival
            return festivalRepository.save(festival);
        }
        throw new RuntimeException("Festival or Band not found");
    }
    public List<Band> getBandsByFestival(long id) {
        Optional<Festival> festivalOptional = festivalRepository.findById(id);
        if (festivalOptional.isPresent()) {
            return new ArrayList<>(festivalOptional.get().getBands());
        }
        throw new RuntimeException("Festival not found");
    }

}

