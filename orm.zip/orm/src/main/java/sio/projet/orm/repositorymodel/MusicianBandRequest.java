package sio.projet.orm.repositorymodel;

import java.time.LocalDate;

public class MusicianBandRequest {
    private LocalDate joinDate;
    private LocalDate leaveDate;

    public LocalDate getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(LocalDate joinDate) {
        this.joinDate = joinDate;
    }

    public LocalDate getLeaveDate() {
        return leaveDate;
    }

    public void setLeaveDate(LocalDate leaveDate) {
        this.leaveDate = leaveDate;
    }
}

