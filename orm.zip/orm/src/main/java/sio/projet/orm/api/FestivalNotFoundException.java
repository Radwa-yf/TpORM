package sio.projet.orm.api;

public class FestivalNotFoundException extends Throwable {
}
