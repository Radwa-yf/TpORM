package sio.projet.orm.api;

public class ResourceNotFoundException {
    public ResourceNotFoundException(String s) {
    }
}
