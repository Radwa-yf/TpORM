package sio.projet.orm;


import org.springframework.web.bind.annotation.*;
import sio.projet.orm.api.FestivalNotFoundException;
import sio.projet.orm.api.model.FestivalCreationRequest;
import sio.projet.orm.repositorymodel.Band;
import sio.projet.orm.repositorymodel.Festival;
import sio.projet.orm.service.FestivalService;

import java.util.List;

@RestController
@RequestMapping("/api/v1/festivals")
public class FestivalController {
    private final FestivalService festivalService;

    public FestivalController(FestivalService festivalService) {
        this.festivalService = festivalService;
    }

    @PostMapping
    public Festival createFestival(@RequestBody FestivalCreationRequest festivalCreationRequest) {
        return festivalService.createFestival(festivalCreationRequest);
    }

    @GetMapping("/{id}")
    public Festival getFestival(@PathVariable long id) throws FestivalNotFoundException {
        return festivalService.getFestival(id).orElseThrow();
    }
    @PostMapping("/{id}/bands/{bandId}")
    public Festival addBandToFestival(@PathVariable long id, @PathVariable long bandId) {
        return festivalService.addBandToFestival(id, bandId);
    }
    @GetMapping("/{id}/bands")
    public List<Band> getBandsByFestival(@PathVariable long id) {
        return festivalService.getBandsByFestival(id);
    }

}

