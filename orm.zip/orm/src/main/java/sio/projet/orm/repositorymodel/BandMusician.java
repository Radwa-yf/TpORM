package sio.projet.orm.repositorymodel;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "BAND_MUSICIAN")
public class BandMusician {
    @EmbeddedId
    private BandMusicianId id;

    @ManyToOne
    @MapsId("musicianId")
    @JoinColumn(name = "musician_id")
    @JsonIgnore
    private Musician musician;

    @ManyToOne
    @MapsId("bandId")
    @JoinColumn(name = "band_id")
    @JsonIgnore
    private Band band;

    @Column(name = "join_date")
    private LocalDate joinDate;

    @Column(name = "leave_date")
    private LocalDate leaveDate;

    public BandMusician(BandMusicianId id, Musician musician, Band band, LocalDate joinDate, LocalDate leaveDate) {
        this.id = id;
        this.musician = musician;
        this.band = band;
        this.joinDate = joinDate;
        this.leaveDate = leaveDate;
    }

    public BandMusician() {

    }

    public BandMusicianId getId() {
        return id;
    }

    public void setId(BandMusicianId id) {
        this.id = id;
    }

    public Musician getMusician() {
        return musician;
    }

    public void setMusician(Musician musician) {
        this.musician = musician;
    }

    public Band getBand() {
        return band;
    }

    public void setBand(Band band) {
        this.band = band;
    }

    public void setJoinDate(LocalDate joinDate) {
        this.joinDate = joinDate;
    }

    public void setLeaveDate(LocalDate leaveDate) {
        this.leaveDate = leaveDate;
    }

    public LocalDate getJoinDate() {
        return joinDate;
    }

    public LocalDate getLeaveDate() {
        return leaveDate;
    }
}

