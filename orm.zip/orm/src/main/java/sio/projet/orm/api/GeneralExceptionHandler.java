package sio.projet.orm.api;

public class GeneralExceptionHandler {
}
