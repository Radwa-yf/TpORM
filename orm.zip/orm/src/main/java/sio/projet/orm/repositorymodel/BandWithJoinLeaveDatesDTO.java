package sio.projet.orm.repositorymodel;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class BandWithJoinLeaveDatesDTO {
    private Long id;
    private String bandName;
    private LocalDate joinDate;
    private LocalDate leaveDate;

    public BandWithJoinLeaveDatesDTO() {
    }

    public BandWithJoinLeaveDatesDTO(Long id, String bandName, LocalDate joinDate, LocalDate leaveDate) {
        this.id = id;
        this.bandName = bandName;
        this.joinDate = joinDate;
        this.leaveDate = leaveDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBandName() {
        return bandName;
    }

    public void setBandName(String bandName) {
        this.bandName = bandName;
    }

    public LocalDate getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(LocalDate joinDate) {
        this.joinDate = joinDate;
    }

    public LocalDate getLeaveDate() {
        return leaveDate;
    }

    public void setLeaveDate(LocalDate leaveDate) {
        this.leaveDate = leaveDate;
    }

    public static BandWithJoinLeaveDatesDTO fromEntity(Band band, BandMusician bandMusician) {
        return new BandWithJoinLeaveDatesDTO(
                band.getId(),
                band.getBandName(),
                bandMusician.getJoinDate(),
                bandMusician.getLeaveDate()
        );
    }
}



