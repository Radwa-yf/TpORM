package sio.projet.orm.api;

public class BandNotFoundException extends Throwable {
}
