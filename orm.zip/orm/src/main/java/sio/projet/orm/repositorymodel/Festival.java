package sio.projet.orm.repositorymodel;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonManagedReference;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "FESTIVAL")
public class Festival {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "city")
    private String city;

    @Column(name = "date")
    private LocalDate date;

    @Column(name = "price")
    private double price;


    @JsonManagedReference
    @ManyToMany(mappedBy = "festivals", cascade = CascadeType.ALL)
    private Set<Band> bands = new HashSet<>();

    public void addBand(Band band) {
        if (!this.bands.contains(band)) {
            this.bands.add(band);
            band.addFestival(this);  // Ajoute le festival à la liste des festivals du groupe
        }
    }


    public Festival(Long id, String name, String city, LocalDate date, double price, List<Band> bands) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.date = date;
        this.price = price;
        this.bands = (Set<Band>) bands;
    }

    public Festival() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public List<Band> getBands() {
        return new ArrayList<>(bands);
    }


    public void setBands(List<Band> bands) {
        this.bands = (Set<Band>) bands;
    }
}
